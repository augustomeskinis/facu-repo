/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoej03;

/**
 *
 * @author Augusto
 */
public class Gira extends Recital {
    private String nombreGira;
    private Fecha vectorFechas [];
    private int dl=0;
    private int df=0;
    private int actual = 0;
    
    public Gira (String unNombreBanda, int unaCant, String unNombreGira, int cantFechas) {
        super(unNombreBanda,unaCant);
        this.nombreGira=unNombreGira;
        this.df=cantFechas;
        vectorFechas = new Fecha [this.df];
    }
    
    public void agregarFecha (Fecha F){
        vectorFechas[dl]=F;
        dl++;
    }
    
    
    
    public void actuar (){
        System.out.println("buenos noches... " + this.vectorFechas[actual].getCiudad());
        super.actuar();
        actual++;
    }
    
    
    
    public int CalcularCosto(){
        int aux=0;
        for(int i=0; i<df;i++){
            if (vectorFechas[i]!=null) {
                aux+= 30000;
            }
        }
        return aux;
    }
    
    
    
    
    
    
    
    
    
    
    
}
