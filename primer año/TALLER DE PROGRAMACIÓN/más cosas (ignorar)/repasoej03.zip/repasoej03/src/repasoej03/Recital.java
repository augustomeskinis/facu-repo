/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoej03;

/**
 *
 * @author Augusto
 */
public abstract class Recital {
    private String nombreBanda;
    private String vectorTemas [];
    private int df;
    private int dl;
    
    public Recital (String unNombre, int cantTemas){
        this.nombreBanda = unNombre;
        this.df=cantTemas;
        vectorTemas = new String[df];
    }
    
    public void agregarTema (String unTema){
        if(dl<df){
            this.vectorTemas[dl]=unTema;
            dl++;
    }
    }
    public void actuar (){
        for(int i=0; i<dl;i++){
            System.out.println("y ahora tocaremos... " + this.vectorTemas[i] +"\n");
        }
    }
    
    public abstract int CalcularCosto();
    
    
    
}
