/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoej03;

/**
 *
 * @author Augusto
 */
public class Repasoej03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        EventoOcasional E = new EventoOcasional("paramore",3,"show de TV","juan",5);
        E.agregarTema("all i wanted");
        E.agregarTema("aint it fun");
        E.agregarTema("figure 8");
        E.actuar();
        System.out.println(E.CalcularCosto());
        Gira G = new Gira("taylor",2,"eras",3);
        G.agregarTema("blank space");
        G.agregarTema("you belong with me");
        Fecha f1=new Fecha("tokyo",1);
        G.agregarFecha(f1);
        Fecha f2= new Fecha("ba",2);
        G.agregarFecha(f2);
        G.actuar();
        System.out.println(G.CalcularCosto());
        
    }
    
}
