/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoej03;

/**
 *
 * @author Augusto
 */
public class Fecha {
    private String ciudad;
    private int dia;
    
    public Fecha (String unaCiudad, int unDia){
        this.ciudad=unaCiudad;
        this.dia=unDia;
    }

    public String getCiudad() {
        return ciudad;
    }

    public int getDia() {
        return dia;
    }
  
    
}
