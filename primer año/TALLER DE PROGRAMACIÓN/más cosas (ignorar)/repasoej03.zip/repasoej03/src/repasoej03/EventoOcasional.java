/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package repasoej03;

/**
 *
 * @author Augusto
 */
public class EventoOcasional extends Recital {
    private String motivo;
    private String nombreC;
    private int dia;
    
    public EventoOcasional(String unNombreBanda, int unaCant, String unMotivo,
                           String unNombreC, int unDia){
        super(unNombreBanda,unaCant);
        this.motivo=unMotivo;
        this.nombreC=unNombreC;
        this.dia=unDia;
    }
    
    public void actuar(){
        if(this.motivo=="show de beneficiencia"){
            System.out.println("y recuerden colaborar con... "+this.nombreC);
        }
        else
            if(this.motivo=="show de TV"){
                System.out.println("Saludos amigos televidentes");
            }
            else {
                System.out.println("Un feliz cumpleaños para... "+this.nombreC);
            }
        super.actuar();
    }
    
    public int CalcularCosto(){
        int costo=0;
        if(this.motivo=="show de TV"){
            costo=50000;
        }
        else {
            if(this.motivo=="show privado"){
                costo=150000;
            }
        }
        return costo;
    }
    
    
}
